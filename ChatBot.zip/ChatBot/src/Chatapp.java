import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import com.sun.speech.freetts.Voice;
import com.sun.speech.freetts.VoiceManager;
import com.sun.speech.freetts.audio.JavaClipAudioPlayer;
import java.awt.Toolkit;
import java.awt.event.WindowEvent;
import java.sql.SQLException;
import javax.swing.JFrame;

public class Chatapp extends javax.swing.JFrame {
    private JFrame frame;
    private static final String jarvis = "kevin16";
    
    public Chatapp() {
        initComponents();
    }    
    public void close(){
        WindowEvent winClosingEvent = new WindowEvent(this,WindowEvent.WINDOW_CLOSING);
        Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(winClosingEvent);
 
 }
    public void phones(){
        Voice iTalk;
        String msg="";
        int count=0;
        int msgcount=0;
        VoiceManager iSpeak = VoiceManager.getInstance();
        iTalk = iSpeak.getVoice(jarvis);
        iTalk.allocate();
            iTalk.speak("Please enter your desired specifications for better results.");
            msgbox.append("\n\nJ.A.R.V.I.S.>> Please enter your desired specifications for better \nresults.");
            String price = JOptionPane.showInputDialog("Please enter your Maximum Price affordablity:");
            String cam = JOptionPane.showInputDialog("Please enter your minimum Camera requirements if any, else enter 'None':");
            String battery = JOptionPane.showInputDialog("Please enter minimum Battery requirements(mAh), else enter 'None':");
            String mindisp = JOptionPane.showInputDialog("Please enter the preferred minimum size of Phone, else enter 'None':");
            String maxdisp = JOptionPane.showInputDialog("Please enter the preferred maximum size of Phone, else enter 'None':");
            String ram = JOptionPane.showInputDialog("Please enter the expected RAM for your phone, else enter 'None':");
            String rom = JOptionPane.showInputDialog("Please enter the preferred minimum Internal Memory, else enter 'None':");
            String query = "select * from phones where Price <="+price+" and RAM >= "+ram+" and Internal_Memory>= "+rom+" and Battery_Life_mAh>= "+battery+" "
                            + "and Camera>= "+cam+" and Display_inch<= "+maxdisp+" and Display_inch>= "+mindisp+";";
             try{
                Class.forName("java.sql.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost/nlp", "root", "");
                Statement st = con.createStatement();
                ResultSet rs = st.executeQuery(query);
                msgbox.append("\n\nJ.A.R.V.I.S>> Here are the results");
                String temp="Here are the results";
                iTalk.allocate();
                iTalk.speak(temp);
                while (rs.next()) {
                    String Ph_ID = rs.getString("Ph_ID");
                    String brand = rs.getString("Brand");
                    String Model = rs.getString("Model");
                    String OS = rs.getString("Type");
                    String Camera = rs.getString("Camera");
                    String Battery = rs.getString("Battery_Life_mAh");
                    String Display = rs.getString("Display_inch");
                    String RAM = rs.getString("RAM");
                    String ROM = rs.getString("Internal_Memory");
                    String Price = rs.getString("Price");
                    msg = "\n\nMobile "+count+":\n\n"
                    + brand+Model+"\nType: "+OS+",\n"+Camera+"MP Camera, \nBattery - "+Battery+"mAh. \nDisplay - "+Display+" inches. \n"
                            + "Internal Memory - "+ ROM+"GB and "+RAM+"GB RAM. \nBest price Rs."+Price+" /-";
                    msgbox.append(msg);
                    count++;
                }
                if (msg == null){
                    msgbox.append("\n\nJ.A.R.V.I.S>> Couldn't find as per your choice or you have not entered the required data. :D\n\n");
                    iTalk.allocate();
                    iTalk.speak("Couldn't find as per your choice or you have not entered the required data.");
                }
                else{
                    msginput.setText(null);
                    msgbox.append("\n\nJ.A.R.V.I.S>> Feel free to converse if you need any more help! :D\n\n");
                
                    msgbox.append("\n\nJ.A.R.V.I.S>> Also, Would you like to compare phones as per your \nchoice? If yes, simply type 'compare':D\n\n");
                    
                    iTalk.speak("Also, Would you like to compare phones as per your choice? If yes, simply type 'compare'");
                }    
                con.close();
                st.close();
            } 
             catch (ClassNotFoundException | SQLException e1) {
                JOptionPane.showMessageDialog(null, e1.getMessage());      // TODO add your handling code here:
            }
             msgcount++;
             
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        msgbox = new javax.swing.JTextArea();
        msginput = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        msgbox.setEditable(false);
        msgbox.setColumns(20);
        msgbox.setFont(new java.awt.Font("Monospaced", 0, 18)); // NOI18N
        msgbox.setRows(5);
        jScrollPane1.setViewportView(msgbox);
        msgbox.getAccessibleContext().setAccessibleParent(this);

        msginput.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        msginput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                msginputActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Calibri", 1, 48)); // NOI18N
        jLabel1.setText("User:");

        jButton1.setBackground(new java.awt.Color(51, 51, 255));
        jButton1.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        jButton1.setText("SEND");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 768, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(msginput, javax.swing.GroupLayout.PREFERRED_SIZE, 533, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap(20, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 645, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(msginput)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(56, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
String input = msginput.getText();
String Sbot = "";
int count = 1;

msgbox.append("\n\nUSER>> "+input);
input = input.replace("."," ");
String[] words = input.split(" ");
Voice iTalk;
VoiceManager iSpeak = VoiceManager.getInstance();
iTalk = iSpeak.getVoice(jarvis);
String a;
Payment nextPage = new Payment();
String msg = null;
int msgcount=0;
if("How are you?".equalsIgnoreCase(input)||"What's up?".equalsIgnoreCase(input)){
    Sbot = "Am doing good! Thanks for asking! It's always comforting to know that humans care about machines like me!";
}
for(int i=0;i<words.length;i++)
{     
    a = words[i];
    if("Hi".equalsIgnoreCase(a)||"Hello".equalsIgnoreCase(a)||"What's up".equalsIgnoreCase(a)||"Hey".equalsIgnoreCase(a))
    {  
        Sbot = a+" user! How are you!";
        msgcount++;
    }
    else if("How".equalsIgnoreCase(a) && "are".equalsIgnoreCase(words[i+1]) && ("you?".equalsIgnoreCase(words[i+2])||"you".equalsIgnoreCase(words[i+2])))
    {   
        Sbot = "Am doing good! Thanks for asking! It's always \ncomforting to know that humans care about machines like me!";   
        msgcount++;
    }
    else if(("fine".equalsIgnoreCase(a)||"good".equalsIgnoreCase(a)||"great".equalsIgnoreCase(a)) && i==(words.length-1))
        {
                Sbot = " Well that's great! How may I help you today?";
                msgcount++;     
        }
    else if(("fine".equalsIgnoreCase(a)||"good".equalsIgnoreCase(a)||"great".equalsIgnoreCase(a)) && i<(words.length-1))
        {
            if("phones".equalsIgnoreCase(words[i+1])||"mobiles".equalsIgnoreCase(words[i+1])||"mobile".equalsIgnoreCase(words[i+1])||"phone".equalsIgnoreCase(words[i+1])){
                phones();
                msgcount++;
            }
            else{
                Sbot = " Well that's great! How may I help you today?";
                msgcount++;
            }
        }
    
    else if("bad".equalsIgnoreCase(a)||"worse".equalsIgnoreCase(a)||"worst".equalsIgnoreCase(a)||"dark".equalsIgnoreCase(a)||"sad".equalsIgnoreCase(a))
        {
            Sbot = " Oh! Maybe shopping might cheer you up? Or would you like a joke? That might cheer you up too! What do you call security guard at Samsung Store? It's simple: Guardians of the Galaxy!";
            msgcount++;
        }
    else if("help".equalsIgnoreCase(a))
    {
        Sbot = "I am here for your help only. I can help you find Phones according to your specifications. \n I am also able to compare mobiles. My developer is working on comparing more than 2 mobiles. ";
        msgcount++;
    }
    else if("thanks".equalsIgnoreCase(a)||"thank".equalsIgnoreCase(a)||"Cheered".equalsIgnoreCase(a)||"funny".equalsIgnoreCase(a))
        {
            Sbot = "Am glad I could help you out! :D. Would you like me to look for something else for you?"; 
            msgcount++;
        }
    else if("bored".equalsIgnoreCase(a)||"exhausted".equalsIgnoreCase(a)||"tired".equalsIgnoreCase(a)||"irritated".equalsIgnoreCase(a))
        {
            Sbot = "I understand, you had a long day! Why don't you \nlisten somme music or share your experience. I'll hear you out."; 
            msgcount++;
            
        }
    else if("purchase".equalsIgnoreCase(a)||"buy".equalsIgnoreCase(a)){
        
        nextPage.setVisible(true);
        
    }
    else if("iphone".equalsIgnoreCase(a)||"iPhones".equalsIgnoreCase(a))
    {
     try{
                Class.forName("java.sql.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost/nlp", "root", "");
                Statement st = con.createStatement();
                String query = "select * from phones where Brand = 'Apple';";
                ResultSet rs = st.executeQuery(query);
                msgbox.append("\n\nJ.A.R.V.I.S>> Here are the results");
                String temp="Here are the results";
                iTalk.allocate();
                iTalk.speak(temp);
                while (rs.next()) {
                    String Ph_ID = rs.getString("Ph_ID");
                    String brand = rs.getString("Brand");
                    String Model = rs.getString("Model");
                    String OS = rs.getString("Type");
                    String Camera = rs.getString("Camera");
                    String Battery = rs.getString("Battery_Life_mAh");
                    String Display = rs.getString("Display_inch");
                    String RAM = rs.getString("RAM");
                    String ROM = rs.getString("Internal_Memory");
                    String Price = rs.getString("Price");
                    msg = "\n\nMobile "+count+":\n\n"
                    + brand+Model+"\nType: "+OS+",\n"+Camera+"MP Camera, \nBattery - "+Battery+"mAh. \nDisplay - "+Display+" inches. \n"
                            + "Internal Memory - "+ ROM+"GB and "+RAM+"GB RAM. \nBest price Rs."+Price+" /-";
                    msgbox.append(msg);
                    count++;
                }
                if (msg == null){
                    msgbox.append("\n\nJ.A.R.V.I.S>> Couldn't find as per your choice or you have not entered the required data. :D\n\n");
                    iTalk.allocate();
                    iTalk.speak("Couldn't find as per your choice or you have not entered the required data.");
                }
                else{
                    msginput.setText(null);
                    msgbox.append("\n\nJ.A.R.V.I.S>> Feel free to converse if you need any more help! :D\n\n");
                
                    msgbox.append("\n\nJ.A.R.V.I.S>> Also, Would you like to compare phones as per your choice? :D\n\n");
                    iTalk.speak("Also, Would you like to compare phones as per your choice?");
                }    
                con.close();
                st.close();
            } 
             catch (ClassNotFoundException | SQLException e1) {
                JOptionPane.showMessageDialog(null, e1.getMessage());      // TODO add your handling code here:
            }   
     msgcount++;
    }
    
    else if("compare".equalsIgnoreCase(a))
    {
        Float e1 = null,e2 = null,f1 = null,f2 = null,g1 = null,g2 = null,h1 = null,h2 = null,i1 = null,i2 = null,j1 = null,j2 = null;
        String b1 = null,c1 = null,b2 = null,c2 = null, d1 = null, d2 = null;
        String model1 = JOptionPane.showInputDialog("Enter Model of phone : 1"); 
        String query1 = "select * from phones where Model='"+model1+"';"; 
        String model2 = JOptionPane.showInputDialog("Enter Model of phone : 2"); 
        String query2 = "select * from phones where Model='"+model2+"';"; 
        
         
         try{
                Class.forName("java.sql.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost/nlp", "root", "");
                Statement st = con.createStatement();
                ResultSet rs = st.executeQuery(query1);
                while (rs.next()) {
                    String a1 = rs.getString("Ph_ID");
                    b1 = rs.getString("Brand");
                    c1 = rs.getString("Model");
                    d1 = rs.getString("Type");
                    e1= rs.getFloat("Camera");
                    f1 = rs.getFloat("Battery_Life_mAh");
                    g1 = rs.getFloat("Display_inch");
                    h1= rs.getFloat("RAM");
                    i1 = rs.getFloat("Internal_Memory");
                    j1 = rs.getFloat("Price");
                }
                ResultSet rs1 = st.executeQuery(query2);
                while (rs1.next()) 
                {
                    String a2 = rs1.getString("Ph_ID");
                    b2 = rs1.getString("Brand");
                    c2 = rs1.getString("Model");
                    d2 = rs1.getString("Type");
                    e2= rs1.getFloat("Camera");
                    f2 = rs1.getFloat("Battery_Life_mAh");
                    g2 = rs1.getFloat("Display_inch");
                    h2= rs1.getFloat("RAM");
                    i2 = rs1.getFloat("Internal_Memory");
                    j2 = rs1.getFloat("Price");
                    }   
                    iTalk.allocate();
         iTalk.speak("Comparing phones. This might take a while... ");
         iTalk.speak("Aah! Here are your results after comparing");
         msgbox.append("\n\nJ.A.R.V.I.S.>>Comparing phones. This might take a while...");
         int ctr1=0;
         int ctr2=0;
         if(e1 > e2){
             ctr1++;
         }         
         else if(e1 < e2){
             ctr2++;
         }
         else{
             ctr1++;
             ctr2++;
         }
         if(f1 > f2){
             ctr1++;
         }         
         else if(f1 < f2){
             ctr2++;
         }
         else
         {
             ctr1++;
             ctr2++;
         }
         if(g1 > g2){
             ctr1++;
         }         
         else if(g1 < g2){
             ctr1++;
         }
         else
         {
               ctr2++;
               ctr1++;
         }
         if(i1 > i2){
             ctr1++;
         }         
         else if(i1 < i2){
             ctr2++;
         } 
         else
         {
             ctr1++;
             ctr2++;
         }
         if(h1 > h2){
             ctr1++;
         }         
         else if(h1 < h2){
             ctr2++;
         } 
         else
         {
             ctr1++;
             ctr2++;
         }
         if(j1 < j2){
             ctr1++;
         }         
         else if(j1 > j2){
             ctr2++;
         }
         else
         {
             ctr1++;
             ctr2++;
         }
         msg = "\n\nMobile 1:\n\n"+b1+" "+c1+"\nType: "+d1+",\n"+e1+"MP Camera, \nBattery - "+f1+"mAh. \nDisplay - "+g1+" inches. \n"
                            + "Internal Memory - "+ i1+"GB and "+h1+"GB RAM. \nBest price Rs."+j1+" /-"+"\n\nMobile 2:\n\n"+b2+" "+c2+"\nType: "+d2+",\n"+e2+
                 "MP Camera, \nBattery - "+f2+"mAh. \nDisplay - "+g2+" inches. \n"
                            + "Internal Memory - "+ i2+"GB and "+h2+"GB RAM. \nBest price Rs."+j2+" /-";;
                    msgbox.append(msg);
                    count++;
         msgbox.append(msg);
        if(ctr1 > ctr2){
             Sbot = "Mobile "+b1+" "+c1+" is better buy than \n"+b2+" "+c2+" as per the given conditions.";
            }
        else if(ctr1 < ctr2){
            Sbot = "Mobile "+b2+" "+c2+" is better buy than \n"+b1+" "+c1+" as per the given conditions.";
        }
        else{
            Sbot = "Mobile "+b2+" "+c2+" and \n"+b1+" "+c1+" are both equally great phones.";
        }
                con.close();
                st.close();
            } 
             catch (ClassNotFoundException | SQLException e) {
                JOptionPane.showMessageDialog(null, e.getMessage());      // TODO add your handling code here:
            }
        msgcount++;
    }
    else if("phone".equalsIgnoreCase(a)||"phones".equalsIgnoreCase(a)||"mobiles".equalsIgnoreCase(a)||"mobile".equalsIgnoreCase(a) && msgcount==0)
    {
        phones();
    }  
    else 
    {
        if(i==words.length-1 && msgcount == 0)
            Sbot = " Sorry I didn't understand that! Am still Learning.!";
        else
            continue;
    }
    
    msgbox.append("\n\nJ.A.R.V.I.S>> "+Sbot+"\n\n");
    iTalk.allocate();
    iTalk.speak(Sbot);
    msginput.setText(null);
}
    }//GEN-LAST:event_jButton1ActionPerformed

    private void msginputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_msginputActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_msginputActionPerformed

    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
// TODO add your handling code here:
    }//GEN-LAST:event_formWindowActivated

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
Voice iTalk;
VoiceManager iSpeak = VoiceManager.getInstance();
iTalk = iSpeak.getVoice(jarvis);
iTalk.allocate();
iTalk.speak("Hey User! How are you?");
msgbox.append("J.A.R.V.I.S.>> Hey User! How are you?");// TODO add your handling code here:
    }//GEN-LAST:event_formWindowOpened

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]){
        
         //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Chatapp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Chatapp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Chatapp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Chatapp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Chatapp().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea msgbox;
    private javax.swing.JTextField msginput;
    // End of variables declaration//GEN-END:variables
}
